# Anki Evernote Importer

Anki Evernote Importer 是一款将印象笔记导入自动化的 Anki 2.1 插件。

用户文档和开发者文档参见[本项目的 GitHub 主页](https://tansongchen.com/AnkiEvernoteImporter)。

如您在使用中遇到问题或对插件功能有好的建议，欢迎通过以下两种方式之一与我联系：

- 在[本项目的 Issue 页面](https://github.com/tansongchen/AnkiEvernoteImporter/issues)提交 Issue；
- 发送邮件至 tansongchen@pku.edu.cn
